const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 1 }
});
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const uuid = () => crypto.randomUUID();

function safeJson(text, label) {
  try { return JSON.parse(text); }
  catch { throw new Error(`${label} is not valid JSON.`); }
}

function validateManifest(manifest, label) {
  const errors = [];
  if (!manifest || typeof manifest !== "object") return [`${label}: manifest must be a JSON object.`];
  if (!manifest.format_version) errors.push(`${label}: missing format_version.`);
  if (!manifest.header || !manifest.header.name) errors.push(`${label}: missing header.name.`);
  if (!manifest.header || !manifest.header.uuid) errors.push(`${label}: missing header.uuid.`);
  if (!manifest.header || !manifest.header.version) errors.push(`${label}: missing header.version.`);
  if (!Array.isArray(manifest.modules) || !manifest.modules.length) errors.push(`${label}: modules must be a non-empty array.`);
  for (const [i, mod] of (manifest.modules || []).entries()) {
    if (!mod.uuid) errors.push(`${label}: module ${i + 1} is missing uuid.`);
    if (!mod.type) errors.push(`${label}: module ${i + 1} is missing type.`);
    if (!mod.version) errors.push(`${label}: module ${i + 1} is missing version.`);
  }
  return errors;
}

function makeBedrockPack(name, description, type) {
  const headerId = uuid();
  const moduleId = uuid();
  const manifest = {
    format_version: 2,
    header: { name, description, uuid: headerId, version: [1, 0, 0], min_engine_version: [1, 20, 0] },
    modules: [{ type, uuid: moduleId, version: [1, 0, 0] }]
  };
  if (type === "data") {
    manifest.modules[0].description = description;
  }
  return manifest;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "ModMaker", features: ["bedrock-packaging", "bedrock-manifest-validation", "java-project-template"] });
});

app.post("/api/bedrock/create", (req, res) => {
  try {
    const name = String(req.body.name || "My Mod").trim().slice(0, 60);
    const description = String(req.body.description || "Created with ModMaker").trim().slice(0, 200);
    const behavior = makeBedrockPack(`${name} BP`, description, "data");
    const resource = makeBedrockPack(`${name} RP`, description, "resources");
    const errors = [
      ...validateManifest(behavior, "Behavior pack"),
      ...validateManifest(resource, "Resource pack")
    ];
    if (errors.length) return res.status(400).json({ ok: false, errors });

    const zip = new AdmZip();
    zip.addFile(`${name.replace(/[^a-z0-9_-]/gi, "_")}_BP/manifest.json`, Buffer.from(JSON.stringify(behavior, null, 2)));
    zip.addFile(`${name.replace(/[^a-z0-9_-]/gi, "_")}_RP/manifest.json`, Buffer.from(JSON.stringify(resource, null, 2)));
    zip.addFile("README.txt", Buffer.from(
      `${name}\nCreated with ModMaker.\n\nThis starter add-on contains valid behavior/resource pack manifests.\nAdd your custom entities, items, blocks, functions and textures before using it in a world.\nImport the .mcaddon file into Minecraft Bedrock, then enable both packs in your world's settings.\n`
    ));
    const out = zip.toBuffer();
    res.set({
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${name.replace(/[^a-z0-9_-]/gi, "_")}.mcaddon"`,
      "X-ModMaker-Validation": "passed"
    });
    res.send(out);
  } catch (e) {
    res.status(400).json({ ok: false, errors: [e.message] });
  }
});

app.post("/api/bedrock/validate", upload.single("project"), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok: false, errors: ["Choose a .zip, .mcpack or .mcaddon file."] });
    const zip = new AdmZip(req.file.buffer);
    const entries = zip.getEntries();
    const manifests = entries.filter(e => /(^|\/)manifest\.json$/i.test(e.entryName));
    if (!manifests.length) return res.json({ ok: false, errors: ["No manifest.json was found in the archive."] });
    const errors = [];
    const checked = [];
    for (const entry of manifests) {
      const parsed = safeJson(entry.getData().toString("utf8"), entry.entryName);
      errors.push(...validateManifest(parsed, entry.entryName));
      checked.push(entry.entryName);
    }
    res.json({ ok: errors.length === 0, checked, errors, message: errors.length ? "Manifest checks found problems." : "Manifest JSON and required fields passed basic validation." });
  } catch (e) {
    res.status(400).json({ ok: false, errors: [e.message] });
  }
});

app.get("/api/java/starter", (_req, res) => {
  const project = new AdmZip();
  const files = {
    "settings.gradle": "pluginManagement { repositories { gradlePluginPortal(); maven { url = 'https://maven.fabricmc.net/' } } }\nrootProject.name = 'ModMakerStarter'\n",
    "build.gradle": `plugins {\n    id 'fabric-loom' version '1.9-SNAPSHOT'\n}\n\nversion = '1.0.0'\ngroup = 'com.example'\n\nrepositories { mavenCentral() }\n\ndependencies {\n    minecraft 'com.mojang:minecraft:1.21.1'\n    mappings 'net.fabricmc:yarn:1.21.1+build.3:v2'\n    modImplementation 'net.fabricmc:fabric-loader:0.16.5'\n}\n\nprocessResources {\n    inputs.property 'version', project.version\n    filesMatching('fabric.mod.json') { expand 'version': project.version }\n}\n`,
    "gradle.properties": "org.gradle.jvmargs=-Xmx2G\n",
    "src/main/resources/fabric.mod.json": JSON.stringify({
      schemaVersion: 1, id: "modmaker_starter", version: "${version}", name: "ModMaker Starter",
      description: "A starter mod project created with ModMaker.", authors: ["ModMaker"],
      environment: "*", entrypoints: { main: ["com.example.ModMakerStarter"] },
      depends: { fabricloader: ">=0.16.0", minecraft: "~1.21.1", java: ">=21" }
    }, null, 2),
    "src/main/java/com/example/ModMakerStarter.java": `package com.example;\n\nimport net.fabricmc.api.ModInitializer;\nimport org.slf4j.Logger;\nimport org.slf4j.LoggerFactory;\n\npublic class ModMakerStarter implements ModInitializer {\n    public static final String MOD_ID = "modmaker_starter";\n    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);\n\n    @Override\n    public void onInitialize() {\n        LOGGER.info("Hello from your ModMaker starter mod!");\n    }\n}\n`,
    "README.md": "# ModMaker Java Starter\n\nThis is a Fabric starter project for Minecraft Java Edition 1.21.1.\n\n## Requirements\n- Java 21\n- Gradle 8.10 or compatible Gradle installation\n\n## Build\nRun `gradle build` from this folder. The built mod JAR will be in `build/libs/`.\n\nInstall Fabric Loader for the matching Minecraft version and place the JAR in your `.minecraft/mods` folder.\n\nThis is a starter template, not a full mod compiler service. ModMaker's hosted Java build sandbox and in-game runtime testing still need to be deployed.\n"
  };
  for (const [name, content] of Object.entries(files)) project.addFile(`ModMakerJavaStarter/${name}`, Buffer.from(content));
  const out = project.toBuffer();
  res.set({ "Content-Type": "application/zip", "Content-Disposition": 'attachment; filename="ModMakerJavaStarter.zip"' });
  res.send(out);
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ModMaker running on http://localhost:${port}`));
