# ModMaker — Minecraft Studio starter

This is an early full-stack starter for a ModMaker website supporting Minecraft Bedrock and Java editions.

## Run locally

Requirements: Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000

## Included now

- Dark ModMaker landing page and studio UI.
- Bedrock `.mcaddon` starter package generation with behavior/resource pack manifest files.
- Basic Bedrock archive manifest validation.
- Java Edition Fabric starter project export (Minecraft 1.21.1 / Java 21).
- Coding Mode scratchpad and AI Maker project brief input.

## Important limitations

This is a working development starter, not a finished hosted mod platform.

- The Bedrock generator creates a valid starter structure but does not yet generate custom items, mobs, blocks, textures, recipes, scripts or gameplay behavior from prompts.
- Bedrock validation checks archive manifests and required fields; it does not launch Minecraft or verify gameplay.
- Java export gives you a Fabric project scaffold. A production service must add a secure isolated Gradle build worker to compile arbitrary projects.
- Real Java/Bedrock in-game testing needs isolated Minecraft test environments, version-specific runtimes and automated test plans.
- AI generation is not connected to an AI model yet.
- Public publishing requires a hosting provider, domain/DNS setup, HTTPS, persistent storage, deployment secrets and operational monitoring.

## Production roadmap

1. Add user accounts, saved projects and project version history.
2. Connect an AI service to generate actual pack/mod source files.
3. Build secure isolated Java build workers (never compile untrusted uploads in the web process).
4. Add Bedrock schema checks and scripted validation against supported engine versions.
5. Add dedicated test workers for supported Minecraft versions and mod loaders.
6. Add export/import guidance, build logs and reproducible artifacts.
7. Deploy to a hosting provider and connect a registered domain.

## Minecraft publishing notes

- Bedrock: users can import `.mcaddon` files by opening them with Minecraft, then enable the behavior/resource packs in world settings.
- Java: users need the matching Fabric Loader and Minecraft version; place the built `.jar` in the game's `mods` folder.
- Publishing to the official Minecraft Marketplace is separate and requires the applicable partner/approval process.

ModMaker is an independent project and is not affiliated with Mojang or Microsoft.


## Quick temporary hosting with Render

1. Upload this project folder to a GitHub repository.
2. Sign in to Render and choose **New → Blueprint** (or create a Web Service from the repository).
3. Select the repository containing `render.yaml`.
4. Render reads the configuration, installs dependencies and runs `npm start`.
5. When deployment succeeds, Render gives the service an `*.onrender.com` URL.

The free web service may sleep after 15 minutes without traffic and can take about a minute to wake up. Its local filesystem is temporary, so this starter's project data is not durable yet. Add a persistent database/storage layer before inviting users to save important work.
